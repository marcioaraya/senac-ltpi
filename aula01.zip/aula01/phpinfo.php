<?php

/* 
  Mostra todas as informações, 
  usa o padrão INFO_ALL
*/

phpinfo();

?>
