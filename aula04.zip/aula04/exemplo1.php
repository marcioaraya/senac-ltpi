<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $nota1 = 5.0;
        $nota2 = 6.0;
        $nota3 = 5.5;
        $nota4 = 7.0;

        $media = ($nota1 + $nota2 + $nota3 + $nota4)/4;

        echo "<p>A média das notas é ".$media."</p>";

    ?>
</body>
</html>