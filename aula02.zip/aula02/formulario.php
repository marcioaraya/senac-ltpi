<!DOCTYPE html>
<html>
<head>
	<title>Exemplos</title>
	<meta charset="UTF-8"> </head>
<body>
<form action="ola.php" method="GET">  
	Nome: <input type="text" name="nome">
	<br>  	
	Sobrenome: <input type="text" name="sobrenome">
	<br>
	Idade: <input type="text" name="idade">
	<br>	
	<input type="submit" value="Submit">
</form>
</body>
</html>
